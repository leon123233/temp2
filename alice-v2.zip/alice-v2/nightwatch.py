#coding=utf-8
import time
from datetime import datetime
import threading
import copy

def singleton(cls, *args, **kw):  
    instances = {}  
    def _singleton():  
        if cls not in instances:  
            instances[cls] = cls(*args, **kw)  
        return instances[cls]  
    return _singleton

class Timer(threading.Thread):
    def __init__(self,watcher):
        super(Timer,self).__init__()
        self.watcher = watcher

    def run(self):
        while 1:
            temp_record1 = copy.deepcopy(self.watcher.counter)
            time.sleep(2)
            temp_record2 = copy.deepcopy(self.watcher.counter)
            for ip,val in temp_record2.items():
                if ip in temp_record1.keys():
                    if (val-temp_record1[ip]) > 6:
                        self.watcher.set_black(ip)
                        print "set black %s" % ip
                now = int(time.time())
                old_time = self.watcher.timer[ip]
                if now - old_time > 3600:
                   self.watcher.delete_timeout(ip)
            
@singleton
class NightWatch(object):

    max_num = 100000
    def __init__(self):
        self.blacklist = []
        self.timer = {}
        self.counter = {}

    def set_black(self,ip):
        print "SET_BLACK"
        if len(self.blacklist) < self.max_num:
            self.blacklist.append(ip)
        else:
            del self.blacklist[0]
            self.blacklist.append(ip)

    def is_black(self,ip):
        if ip in self.blacklist:
            return True
        return False

    def record(self,ip):
        now = int(time.time())
        if self.counter.get(ip):
            self.counter[ip] += 1
            self.timer[ip] = now
        else:
            self.counter[ip] = 1
            self.timer[ip] = now

    def delete_timeout(self,ip):
        del self.timer[ip]
        del self.counter[ip]
        

