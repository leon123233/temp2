#coding=utf-8
import socket
import struct
import hashlib
import threading,random,uuid
from container import Container
from nightwatch import NightWatch,Timer
import sys
#reload(sys)
#sys.setdefaultencoding('utf-8')


#接收客户端发送过来的消息,并且解包
def RecvData(nNum,client):
    try:
        pData = client.recv(nNum)
        if not len(pData):
            return False
    except:
        return False
    else:
        code_length = ord(pData[1]) & 127
        if code_length == 126:
            masks = pData[4:8]
            data = pData[8:]
        elif code_length == 127:
            masks = pData[10:14]
            data = pData[14:]
        else:
            masks = pData[2:6]
            data = pData[6:]
        
        raw_str = ""
        i = 0
        for d in data:
            raw_str += chr(ord(d) ^ ord(masks[i%4]))
            i += 1
            
        return raw_str
     
class WebSocket(threading.Thread):
    def __init__(self,conn,socket_id,name,remote, path="/"):
        threading.Thread.__init__(self)
        self.conn = conn
        self.socket_id = socket_id
        self.name = name
        self.remote = remote
        self.path = path
        self.buffer = ""
        self.active = True

    #打包发送数据给客户端

    def make_data(self,raw_str):
        back_str = []

        back_str.append('\x81')
        data_length = len(raw_str)

        if data_length < 125:
            back_str.append(chr(data_length))
        else:
            back_str.append(chr(126))
            back_str.append(chr(data_length >> 8))
            back_str.append(chr(data_length & 0xFF))

        back_str = "".join(back_str) + raw_str    
        return back_str

    def run(self):
        #print 'Socket%s Start!' % self.name
        headers = {}
        self.handshaken = False
        watcher = NightWatch()
        while True:
            if self.handshaken == False:
                print 'Socket%s Start Handshaken with %s!' % (self.name,self.remote)
                watcher.record(self.name)
	        if self.name in watcher.blacklist:
                    self.active = False
                    self.conn.close()
                    break
                self.buffer += self.conn.recv(1024)
                if self.buffer.find('\r\n\r\n') != -1:
                    header, data = self.buffer.split('\r\n\r\n', 1)
                    for line in header.split("\r\n")[1:]:
                        key, value = line.split(": ", 1)
                        headers[key] = value
                    #print 'header:-->'+header
                    headers["Location"] = "ws://%s%s" %(headers["Host"], self.path)
                    self.buffer = data[8:]
                    key = headers["Sec-WebSocket-Key"]
                    token = self.generate_token(key)
                    
                    handshake = '\
HTTP/1.1 101 Web Socket Protocol Handshake\r\n\
Upgrade: webSocket\r\n\
Connection: Upgrade\r\n\
Sec-WebSocket-Accept:%s\r\n\
Sec-WebSocket-Origin: %s\r\n\
Sec-WebSocket-Location: %s\r\n\r\n\
' %(token,headers['Origin'], headers['Location'])

                    #print handshake
                    num = self.conn.send(handshake)
                    #print str(num)
                    self.handshaken = True
                    print 'Socket%s Handshaken with %s success!' % (self.name,self.remote)
                    ctn = Container()
                    bstr = self.make_data("&online user: "+str(ctn.user_num()))
                    #print bstr
                    self.conn.send(bstr)

            else:
                self.buffer = RecvData(8196,self.conn)                
                if self.buffer:
                    print 'rec: %r' % self.buffer                   
                if self.buffer:
                    #s = self.buffer.split("\xFF")[0][1:]
                    
                    s = self.buffer
                    if '\\' in '%r' % s:
                        try:
                            s.deocde('utf-8')
                        except:
                            print "Cant decode by utf-8"
                            try:
                                s.decode('gbk')
                            except:
                                print "Cant decode by gbk"
                                if '#quit' in s:
                                    s = '#quit'
                                else:
                                    pass
                    if '#quit' in s and '#quit' == s[0:5]:
                        print 'Socket%s Logout!' % (self.socket_id)
                        self.conn.close()
                        self.active = False
                        break
                    else:
                        print 'Socket%s Got msg:%s from %s!' % (self.socket_id,s,self.remote)
                        ctn = Container()
                        channel = ctn.get_user_channel(self.socket_id)
                        if channel:
                            channel.send_msg(self.socket_id,s)
                        else:
                            res = ctn.brain.answer(s)
                            bstr = self.make_data(res)
                            self.conn.send(bstr)
                    self.buffer = ""
                    
    
    def generate_token(self, key):
        import base64
        nkey=key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11'
        nkey=base64.b64encode(hashlib.sha1(nkey).digest())
        return nkey

class WebSocketServer(object):

    def __init__(self):
        self.socket = None
    def callback(self):
        self.socket.close()
    def begin(self):
        print 'WebSocketServer Start!'
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.bind(("120.24.90.222",49673))
        self.socket.listen(100)
        watcher = NightWatch()
        t = Timer(watcher)
        t.start()
        while True:
            connection, address = self.socket.accept()
            watcher.record(address[0])
            if address[0] in watcher.blacklist:
                print "black ip",address[0]
                connection.close()
                continue
            print "incomming connection!"
            username=address[0]
            socket_id = str(uuid.uuid1())
            newSocket = WebSocket(connection,socket_id,username,address)
            ctn = Container()
            ctn.add_user(newSocket)
            newSocket.start()


if __name__ == "__main__":
    import atexit
    from signal import signal, SIGTERM
    ctn = Container()
    ctn.start()
    print "..."
    server = WebSocketServer()
    atexit.register(server.callback)
    signal(SIGTERM, lambda signum, stack_frame: exit(1))
    server.begin()
