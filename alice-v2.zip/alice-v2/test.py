from channel import Channel
from container import Container
from user import User
import time

ctn = Container()
print id(ctn)
user1 = User(open_id="a")
user2 = User(open_id="b")
user3 = User(open_id="c")

if __name__ == '__main__':
	ctn.start()
	ctn.add_or_update_user(user1)
	ctn.add_or_update_user(user2)
	ctn.add_or_update_user(user3)
	ctn.add_or_update_user(user1)
	cn = Container()
	cn.connect_all()
	channel1 = cn.get_user_channel("a")
	channel2 = cn.get_user_channel("b")
	channel3 = cn.get_user_channel("c")
	print channel1,channel2,channel3,channel1.buffer,channel3.buffer
	channel1.add_msg("a","hehe")
	channel1.add_msg("a","xixi")
	print channel3.buffer
	print channel3.get_one_msg("c")
	channel1.add_msg("a","..")
	channel1.add_msg("a","...")
	channel1.add_msg("a","....")
	#channel1.add_msg("a",".....")
	#channel1.add_msg("a","......")
	print channel1.is_channel_active()
	time.sleep(100)
	ct = Container()
	print ct.current_user_list,ct.channel_list
