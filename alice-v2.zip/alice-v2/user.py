class User(object):
	def __init__(self,open_id):
		super(User, self).__init__()
		self.user_id = open_id

