
MAX_DIFF = 5
class Channel(object):
    def __init__(self,socket1,socket2):
        super(Channel, self).__init__()
        self.socket1 = socket1
        self.socket2 = socket2
        self.context = ""
    def _get_user(self,socket_id):
        if self.socket1.socket_id == socket_id:
            return self.socket1
        elif self.socket2.socket_id == socket_id:
            return self.socket2
        else:
            raise Exception,"exception in _get_user"

    def is_id_in_channel(self,socket_id):
        if socket_id in [self.socket1.socket_id,self.socket2.socket_id]:
            return True
        else:
            return False

    def is_channel_active(self):
        if self.socket1.active and self.socket2.active:
            return True
        return False

    def send_msg(self,socket_id,msg):
        if self.socket1.socket_id == socket_id:
            if self.socket2.active:
                bstr = self.socket2.make_data(msg)
                try:
                    self.socket2.conn.send(bstr)
                    self.context += "user1:"+msg+'\n'
                except:
                    self.socket2.active = False
                    self.socket2.conn.close()
                    return False
                    
        elif self.socket2.socket_id == socket_id:
            if self.socket1.active:
                bstr = self.socket1.make_data(msg)
                try:
                    self.socket1.conn.send(bstr)
                    self.context += "user2:"+msg+'\n'
                except:
                    self.socket1.active = False
                    self.socket1.conn.close()
                    return False
        return True

