#coding=utf-8
import threading
import time
from channel import Channel
from aimlBrain import AlviBrain
import copy
import uuid
from datetime import datetime

def singleton(cls, *args, **kw):  
    instances = {}  
    def _singleton():  
        if cls not in instances:  
            instances[cls] = cls(*args, **kw)  
        return instances[cls]  
    return _singleton

@singleton
class Container(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.brain = AlviBrain()
        self.current_user_list = []
        print "in init"
        self.channel_list = []
    def connect_all(self):
        while len(self.current_user_list) >= 2:
            socket1 = self.current_user_list.pop()
            socket2 = self.current_user_list.pop()
            c = Channel(socket1,socket2)
            self.channel_list.append(c)

    def add_user(self,websocket):
        self.current_user_list.append(websocket)

    def user_num(self):
        return 2*len(self.channel_list) + len(self.current_user_list)

    def get_user_channel(self,socket_id):
        for c in self.channel_list:
            if c.is_id_in_channel(socket_id):
                return c
        return None

    def run(self):
        while True:
            self.connect_all()
            for c in self.channel_list:
                if not c.is_channel_active():
                    with open('log/'+str(int(time.time())),'w') as f:
                        f.write(c.context)
                    self.channel_list.remove(c)
                    if c.socket1.active:
                        self.current_user_list.append(c.socket1)
                    if c.socket2.active:
                        self.current_user_list.append(c.socket2)
            now = datetime.now()
            if now.hour == 3:
                self.current_user_list = []
                print "RESET"
            time.sleep(1)
            a = datetime.now()
            if a.second % 20 == 0:
                print "****************"
                print "Users:",len(self.current_user_list)
                print "Active Users:",len([x for x in self.current_user_list if x.active])
                print "Channels:",len(self.channel_list)
                print "Active Channels:",len([x for x in self.channel_list if x.is_channel_active()])
                print "****************"
